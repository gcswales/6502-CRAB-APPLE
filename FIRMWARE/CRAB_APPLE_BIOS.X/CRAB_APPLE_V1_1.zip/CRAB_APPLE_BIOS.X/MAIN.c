//*************************************************************
//***	FILE:		MAIN.C									***
//***	DATE:		26/09/22								***
//***	AUTHOR:		GEOFFREY SWALES							***
//***	VERSION:	V0.1									***
//*************************************************************
//***	DESCRIPTION:										***
//*************************************************************
//***	VERSION TRACK:										***
//***	V0.1: INITIAL DEVELOPMENT VERSION					***
//***	V1.0:												***
//*************************************************************
//	
//*************************************************************
//*** INCLUDE REQUIRED SPECIFIC DEFINTIONS ********************
//*************************************************************
//
#include <xc.h>
#include "system.h"
#include "uart1.h"
#include "CLOCK.h"
#include "CLC.h"
//
//*************************************************************
//*** STRUCTURE DEFINITIONS ***********************************
//*************************************************************
//
typedef union 
{
	uint8_t arr[5];
	struct
	{
		uint8_t ver;
		uint8_t speed;
		uint16_t baud;
		uint8_t colour;
	} settings;	
} _eprom;
_eprom eprom;
//
//*************************************************************
//*** GLOBAL VARIABLES ****************************************
//*************************************************************
//

//
//*************************************************************
//*** DEFINITIONS *********************************************
//*************************************************************
//
#define	BIOS_VERSION	11									// BIOS version 1.1
#define BIOS_DELAY		20									// BIOS menu wait time (20*100ms)
#define	DEFAULT_SPEED	1									// default clock speed of 1MHz
#define DEFAULT_COLOUR	7									// default text colour is 2 (white)
#define	DEFAULT_BAUD	96									// default baud speed is 9600
//
//*************************************************************
//*** FUNCTION PROTOTYPES *************************************
//*************************************************************
//
void main(void);
void reset_init(void); 
void print_title(void);
void port_service(void);
void clear_screen(void);
void text_colour(uint8_t c);
void bios_menu(void);
void bios_menu_top(void);
void bios_menu_speed(void);
void bios_menu_baud(void);
void bios_menu_colour(void);
void load_settings(void);
void save_settings(void);
void dfm_write(uint16_t adr,uint8_t dat);
uint8_t dfm_read(uint16_t adr);
void menu_print_colour(void);
void bios_menu_title(void);
void bios_waiting(void);
//
//*************************************************************
//*** MAIN ROUTINE ********************************************
//*************************************************************
//
void main(void)
{
	system_init();											// initialise system hardware
	clock_init();											// initialise processor clock
	clc1_init();											// initialise configurable logic control block 1
	clc2_init();											// initialise configurable logic control block 2
	load_settings();										// load BIOS settings from flash
	uart1_init(eprom.settings.baud);						// initialise UART1 based on BIOS BAUD settings
	INTERRUPT_GlobalInterruptHighEnable();					// Enable high priority global interrupts
	INTERRUPT_GlobalInterruptLowEnable();					// Enable low priority global interrupts
	__delay_ms(100);										// small delay to let voltages settle
	print_title();											// print title screen
	bios_menu();											// run BIOS menu (activated by SPACE BAR)
	text_colour(eprom.settings.colour);						// set text colour to user setting
	putch('\r');											// start on a new line
	reset_init();											// perform processor reset sequence
	while(1)												// main loop...
	{
		NOP();												// nothing to do, interrupts handle everything!
	}
}
//
//*************************************************************
//*** INITIALISE RESET LINE SEQUENCE **************************
//*************************************************************
//
void reset_init(void)
{
	while(!BUTTON_GET);										// wait while BUTTON line is low
	__delay_ms(2);											// wait for any button debounce to pass
	clock_set(eprom.settings.speed);						// start CPU clock based on user settings
	__delay_ms(2);											// small delay
	RESET_SET=1;											// set RESET line high - wake up CPU!
}
//
//*************************************************************
//*** CLEAR SCREEN ********************************************
//*************************************************************
//
void clear_screen(void)
{
	printf( "\e[0m\e[2J\e[H\e[1m");							// clear screen, home, bright text
	text_colour(eprom.settings.colour);						// set text colour to user setting
}
//
//*************************************************************
//*** SET TEXT COLOUR *****************************************
//*************************************************************
//
void text_colour(uint8_t c)
{
	printf( "\e[3%um",c);	
}
//
//*************************************************************
//*** PRINT BIOS TITLE SCREEN *********************************
//*************************************************************
//
void print_title(void)
{
	uint8_t v=BIOS_VERSION;
	clear_screen();
	text_colour(2);
	printf("\r                   #");	
	printf("\r                 ###");		
	printf("\r               ####");
	printf("\r               ##");
	printf("\r        ######   ######");	
	printf("\r      ###################");	
	text_colour(3);
	printf("\r     ####################");
	printf("\r     ###################");
	printf("\r    ###################");
	text_colour(1);
	printf("\r    ###################");
	printf("\r    ###################");
	printf("\r    ####################");
	text_colour(5);
	printf("\r     #####################");
	printf("\r     #####################");
	printf("\r      ###################");
	text_colour(4);
	printf("\r       ##################");
	printf("\r        ################");
	printf("\r         #####    ####");
	printf("\r");
	text_colour(7);
	printf("\r     CRAB APPLE BIOS V%u.%u ", v/10,v%10);
}
//
//*************************************************************
//*** SERFVICE BIOS MENU **************************************
//*************************************************************
//
void bios_menu(void)
{
	uint8_t w=BIOS_DELAY;
	while(w--)
	{
		if(kbhit())
		{
			if(getch()==' ')
			{
				bios_menu_top();
			}
			return;
		}
		bios_waiting();	
	}
}
//
//*************************************************************
//*** SERVICES 'ROTATING LINE' PROMPT *************************
//*************************************************************
//
void bios_waiting(void)
{
	static uint8_t i=0;
	switch(i++)
	{
		case 0:
			printf("\b|");
			break;
		case 1:
			printf("\b/");
			break;
		case 2:
			printf("\b-");
			break;
		case 3:
			printf("\b\\");
			i=0;	
			break;			
	}
	__delay_ms(100);
	printf("\b ");
}
//
//*************************************************************
//*** HANDLES BIOS TOP MENU ***********************************
//*************************************************************
//
void bios_menu_top(void)
{
	uint8_t m=0;
	while(m!='\e')
	{
		clear_screen();
		printf ("\r\t1 - PROCESSOR SPEED\r");
		printf ("\r\t2 - UART BAUD RATE\r");
		printf ("\r\t3 - TEXT COLOUR\r");
		printf ("\r\t[ESC] - EXIT\r");
		while(!kbhit());
		m=getch();
		if(m=='1') bios_menu_speed();
		if(m=='2') bios_menu_baud();
		if(m=='3') bios_menu_colour();
	}
	RESET();												// reset everything...
}
//
//*************************************************************
//*** HANDLES BIOS PROCESSOR SPEED MENU ***********************
//*************************************************************
//
void bios_menu_speed(void)
{
	uint8_t m=0;
	while(m!='\e')
	{
		clear_screen();
		printf("\r\tPROCESSOR SPEED : %u MHz\r",eprom.settings.speed );
		printf ("\r\t1 - 1MHz\r");
		printf ("\r\t2 - 2MHz\r");
		printf ("\r\t3 - 4MHz\r");
		printf ("\r\t[ESC] - EXIT\r");
		while(!kbhit());
		m=getch();
		if(m=='1') eprom.settings.speed=1;
		if(m=='2') eprom.settings.speed=2;
		if(m=='3') eprom.settings.speed=4;
	}	
	save_settings();
}
//
//*************************************************************
//*** HANDLES BIOS BAUD RATE MENU *****************************
//*************************************************************
//
void bios_menu_baud(void)
{
	uint8_t m=0;
	while(m!='\e')
	{
		clear_screen();
		printf("\r\tBAUD RATE : %u00\r",eprom.settings.baud );
		printf ("\r\t1 - 9600\r");
		printf ("\r\t2 - 19200\r");
		printf ("\r\t3 - 57600\r");
		printf ("\r\t4 - 115200\r");
		printf ("\r\t[ESC] - EXIT\r");
		while(!kbhit());
		m=getch();
		if(m=='1') eprom.settings.baud=96;
		if(m=='2') eprom.settings.baud=192;
		if(m=='3') eprom.settings.baud=576;
		if(m=='4') eprom.settings.baud=1152;
	}	
	save_settings();
}
//
//*************************************************************
//*** HANDLES BIOS TEXT COLOUR MENU ***************************
//*************************************************************
//
void bios_menu_colour(void)
{
	uint8_t m=0;
	while(m!='\e')
	{
		clear_screen();
		printf("\r\tTEXT COLOUR : ");
		menu_print_colour();
		text_colour(1);
		printf ("\r\t1 - RED\r");
		text_colour(2);
		printf ("\r\t2 - GREEN\r");
		text_colour(3);
		printf ("\r\t3 - YELLOW\r");
		text_colour(4);
		printf ("\r\t4 - BLUE\r");
		text_colour(5);
		printf ("\r\t5 - MAGENTA\r");
		text_colour(6);
		printf ("\r\t6 - CYAN\r");
		text_colour(7);
		printf ("\r\t7 - WHITE\r");
		text_colour(eprom.settings.colour);
		printf ("\r\t[ESC] - EXIT\r");
		while(!kbhit());
		m=getch();
		if(m=='1') eprom.settings.colour=1;
		if(m=='2') eprom.settings.colour=2;
		if(m=='3') eprom.settings.colour=3;
		if(m=='4') eprom.settings.colour=4;
		if(m=='5') eprom.settings.colour=5;
		if(m=='6') eprom.settings.colour=6;
		if(m=='7') eprom.settings.colour=7;
	}
	save_settings();	
}
//
//*************************************************************
//*** PRINTS SELECTED MENU TEXT COLOUR ************************
//*************************************************************
//
void menu_print_colour(void)
{
	switch(eprom.settings.colour)
	{
		default:
		case 1:
			printf("RED\r");
			break;
		case 2:
			printf("GREEN\r");
			break;	
		case 3:
			printf("YELLOW\r");
			break;	
		case 4:
			printf("BLUE\r");
			break;		
		case 5:
			printf("MAGENTA\r");
			break;		
		case 6:
			printf("CYAN\r");
			break;		
		case 7:
			printf("WHITE\r");
			break;			
	}
}
//
//*************************************************************
//*** LOADS USER SETTINGS FROM FLASH DATA *********************
//*************************************************************
//
void load_settings(void)
{
	uint8_t adr=sizeof(_eprom);
	while(adr--)
	{
		eprom.arr[adr]=dfm_read(adr);
	}
	if(eprom.settings.ver!=BIOS_VERSION)
	{
		eprom.settings.ver=BIOS_VERSION;
		eprom.settings.colour=DEFAULT_COLOUR;
		eprom.settings.baud=DEFAULT_BAUD;
		eprom.settings.speed=DEFAULT_SPEED;
		save_settings();
	}
}
//
//*************************************************************
//*** SAVES USER SETTINGS TO FLASH DATA ***********************
//*************************************************************
//
void save_settings(void)
{
	uint8_t adr=sizeof(_eprom);
	while(adr--)
	{
		if(dfm_read(adr)!=eprom.arr[adr])
		{
			dfm_write(adr,eprom.arr[adr]);
		}
	}
}
//
//*************************************************************
//*** READ BYTE FROM DATA FLASH *******************************
//*************************************************************
//
uint8_t dfm_read(uint16_t adr)								// reads data from Data Flash Memory (AKA EEPROM)
{
	NVMADR=0x380000 + adr;									// get address from DFM address plus our offset adr
	NVMCON1bits.CMD=0x00;									// byte read command
	NVMCON0bits.GO=1;										// just do it
	while(NVMCON0bits.GO);									// wait until read is complete
	return(NVMDATL);										// return data
}
//
//*************************************************************
//*** WRITE BYTE TO DATA FLASH ********************************
//*************************************************************
//
void dfm_write(uint16_t adr,uint8_t dat)					// write data to Data Flash Memory (AKA EEPROM)
{
	uint8_t GIEBitValue = INTCON0bits.GIE;					// get status of global interrupt
	NVMADR=0x380000 + adr;									// get address from DFM address plus our offset adr
	NVMDATL = dat;											// Load NVMDAT with the desired value
	NVMCON1bits.CMD = 0x03;									// Set the byte write command	
	INTCON0bits.GIE = 0;									// Disable global interrupt
	NVMLOCK = 0x55;											// flash unlock sequence
	NVMLOCK = 0xAA;											// flash unlock sequence
	NVMCON0bits.GO = 1;										// Start byte write
	while(NVMCON0bits.GO);									// Wait for the write operation to complete
	if (NVMCON1bits.WRERR)									// Verify byte write operation success
	{
		// should do something here but I don't know what!
	}
	INTCON0bits.GIE = GIEBitValue;							// Restore interrupt enable bit value
	NVMCON1bits.CMD = 0;									// Disable writes to memory
}
//
//*************************************************************
//*** END *****************************************************
//*************************************************************
//