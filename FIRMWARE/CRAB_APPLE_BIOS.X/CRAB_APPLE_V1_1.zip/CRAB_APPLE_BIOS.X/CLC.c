//*************************************************************
//***	FILE:		CLC1.C									***
//***	DATE:		07/09/21								***
//***	AUTHOR:		GEOFFREY SWALES							***
//***	VERSION:	V0.1									***
//*************************************************************
//***	DESCRIPTION:										***
//***	PIPES ARE SELF-CONTAINED CIRCULAR BUFFERS WHERE  	***
//***	DATA CAN BE EASILY PUT OR GET FROM BY SIMPLY USING	***
//***	A POINTER TO THE PIPE.								***
//***	THE ROUTINES ARE ATOMIC, SO SAFE TO USE IN BOTH		***
//***	MAIN CODE AND INTERRUPTS.							***
//***	THE WRITE & READ FUNCTIONS CAN BE USED TO PASS		***
//***	OBJECTS OF ANY SIZE, SUCH AS FUNCTION POINTERS, ETC	***
//*************************************************************
//***	VERSION TRACK:										***
//***	V0.1: INITIAL DEVELOPMENT VERSION					***
//***	V1.0:												***
//*************************************************************
//	
//*************************************************************
//*** INCLUDE REQUIRED SPECIFIC DEFINTIONS ********************
//*************************************************************
//
#include "CLC.h"											// include definitions
#include "system.h"											// include pin names
#include "uart1.h"											// include uart
//
//*************************************************************
//*** STRUCTURE DEFINITIONS ***********************************
//*************************************************************
//

//
//*************************************************************
//*** GLOBAL VARIABLES ****************************************
//*************************************************************
//

//
//*************************************************************
//*** INITIALISE CLC1 *****************************************
//*************************************************************
//
void clc1_init(void)										// initialise CLC1 hardware
{
	PMD4bits.CLC1MD=0;										// enable CLC1 module
	CLCSELECTbits.SLCT=0b00;								// select CLC1
	// disable gate
	CLCnCONbits.EN=0;										// disable gate while we configure it
	// data selection
	CLCnSEL0bits.D1S=0;										// select CLCIN0PPS (#IO_CS) for input 1
	CLCnSEL1bits.D2S=1;										// select CLCIN1PPS (IO_EN) for input 2
	CLCnSEL2bits.D3S=1;										// not used
	CLCnSEL3bits.D4S=32;									// select DSM1 (CLOCK) for input 4
	// GATE 1 - AND GATE - INVERT INPUTS, INVERT OUTPUT
	CLCnGLS0bits.G1D1N=0;									// not interested
	CLCnGLS0bits.G1D1T=1;									// when IO_CS goes low -> inverted
	CLCnGLS0bits.G1D2N=1;									// when IO_EN goes high -> inverted
	CLCnGLS0bits.G1D2T=0;									// not interested
	CLCnGLS0bits.G1D3N=0;									// not interested
	CLCnGLS0bits.G1D3T=0;									// not interested
	CLCnGLS0bits.G1D4N=1;									// when CLOCK goes high -> inverted
	CLCnGLS0bits.G1D4T=0;									// not interested
	CLCnPOLbits.G1POL=1;									// invert output
	// GATE 2 - JUST OUTPUTS 1
	CLCnGLS1bits.G2D1N=0;									// not interested
	CLCnGLS1bits.G2D1T=0;									// not interested
	CLCnGLS1bits.G2D2N=0;									// not interested
	CLCnGLS1bits.G2D2T=0;									// not interested
	CLCnGLS1bits.G2D3N=0;									// not interested
	CLCnGLS1bits.G2D3T=0;									// not interested
	CLCnGLS1bits.G2D4N=0;									// not interested
	CLCnGLS1bits.G2D4T=0;									// not interested
	CLCnPOLbits.G2POL=1;									// invert output so it is 1
	// GATE 3 - JUST OUTPUTS 1
	CLCnGLS2bits.G3D1N=0;									// not interested
	CLCnGLS2bits.G3D1T=0;									// not interested
	CLCnGLS2bits.G3D2N=0;									// not interested
	CLCnGLS2bits.G3D2T=0;									// not interested
	CLCnGLS2bits.G3D3N=0;									// not interested
	CLCnGLS2bits.G3D3T=0;									// not interested
	CLCnGLS2bits.G3D4N=0;	    							// not interested
	CLCnGLS2bits.G3D4T=0;									// not interested
	CLCnPOLbits.G3POL=1;									// invert output so it is 1
	// GATE 4 - JUST OUTPUTS 1
	CLCnGLS3bits.G4D1N=0;									// not interested
	CLCnGLS3bits.G4D1T=0;									// not interested
	CLCnGLS3bits.G4D2N=0;									// not interested
	CLCnGLS3bits.G4D2T=0;									// not interested
	CLCnGLS3bits.G4D3N=0;									// not interested
	CLCnGLS3bits.G4D3T=0;									// not interested
	CLCnGLS3bits.G4D4N=0;									// not interested
	CLCnGLS3bits.G4D4T=0;									// not interested
	CLCnPOLbits.G4POL=1;									// invert output so it is 1
	// set logic gate
	CLCnCONbits.MODE=0b010;									// 4-input AND gate
	// logic output polarity
	CLCnPOLbits.POL=0;										// output of logic cell not inverted
	// set logic output interrupts
	CLCnCONbits.INTP=1;										// interrupt on rising edge
	CLCnCONbits.INTN=0;										// no interrupt on falling edge
	// finished so enable the gate
	CLCnCONbits.EN=1;										// enable CLC system
	// config interrupt
	IPR0bits.CLC1IP=1;										// CLC1 is high priority
	PIR0bits.CLC1IF=0;										// CLC1 interrupt flags clear
	PIE0bits.CLC1IE=1;										// enable interrupt for CLC1	
}
//
//*************************************************************
//*** INITIALISE CLC2 *****************************************
//*************************************************************
//
void clc2_init(void)										// initialise CLC2 hardware
{
	PMD4bits.CLC2MD=0;										// enable CLC2 module
	CLCSELECTbits.SLCT=0b01;								// select CLC2
	// disable gate
	CLCnCONbits.EN=0;										// disable gate while we configure it
	// data selection
	CLCnSEL0bits.D1S=0;										// select CLCIN0PPS (ROM_CS) for input 0
	CLCnSEL1bits.D2S=1;										// select CLCIN1PPS (IO_CS) for input 1
	CLCnSEL2bits.D3S=2;										// select CLCIN2PPS (ENABLE) for input 2
	CLCnSEL3bits.D4S=32;									// select DSM1 (CLOCK) for input 3
	// data gate 1 - ROM_CS = 0, IO_CS=0, EN=1, CLK=1
	CLCnGLS0bits.G1D1N=0;									// input 1 negated
	CLCnGLS0bits.G1D1T=0;									// no other input selection
	CLCnGLS0bits.G1D2N=0;									// no other input selection
	CLCnGLS0bits.G1D2T=0;									// no other input selection
	CLCnGLS0bits.G1D3N=0;									// no other input selection
	CLCnGLS0bits.G1D3T=0;									// no other input selection
	CLCnGLS0bits.G1D4N=0;									// no other input selection
	CLCnGLS0bits.G1D4T=0;									// no other input selection
	CLCnPOLbits.G1POL=1;									// output of gate 1 not inverted
	// data gate 2 - IO_CS = 0
	CLCnGLS1bits.G2D1N=0;									// no other input selection
	CLCnGLS1bits.G2D1T=0;									// no other input selection
	CLCnGLS1bits.G2D2N=0;									// input 2 negated
	CLCnGLS1bits.G2D2T=0;									// no other input selection
	CLCnGLS1bits.G2D3N=0;									// no other input selection
	CLCnGLS1bits.G2D3T=0;									// no other input selection
	CLCnGLS1bits.G2D4N=0;									// no other input selection
	CLCnGLS1bits.G2D4T=0;									// no other input selection
	CLCnPOLbits.G2POL=1;									// output of gate 2 not inverted
	// data gate 3 - EN = 1
	CLCnGLS2bits.G3D1N=0;									// no other input selection
	CLCnGLS2bits.G3D1T=0;									// no other input selection
	CLCnGLS2bits.G3D2N=0;									// no other input selection
	CLCnGLS2bits.G3D2T=0;									// no other input selection
	CLCnGLS2bits.G3D3N=0;									// no other input selection
	CLCnGLS2bits.G3D3T=0;									// input 3 true
	CLCnGLS2bits.G3D4N=0;									// no other input selection
	CLCnGLS2bits.G3D4T=0;									// no other input selection
	CLCnPOLbits.G3POL=1;									// output of gate 3 not inverted
	// data gate 4 - A0 = 1
	CLCnGLS3bits.G4D1N=0;									// no other input selection
	CLCnGLS3bits.G4D1T=0;									// no other input selection
	CLCnGLS3bits.G4D2N=0;									// no other input selection
	CLCnGLS3bits.G4D2T=0;									// no other input selection
	CLCnGLS3bits.G4D3N=0;									// no other input selection
	CLCnGLS3bits.G4D3T=0;									// no other input selection
	CLCnGLS3bits.G4D4N=0;									// no other input selection
	CLCnGLS3bits.G4D4T=0;									// input 4 true
	CLCnPOLbits.G4POL=1;									// output of gate 4 not inverted
	// set logic gate
	CLCnCONbits.MODE=0b010;									// 4-input AND gate
	// logic output polarity
	CLCnPOLbits.POL=0;										// output of logic cell not inverted
	// set logic output interrupts
	CLCnCONbits.INTP=0;										// interrupt on rising edge
	CLCnCONbits.INTN=0;										// no interrupt on falling edge
	// finished so enable the gate
	CLCnCONbits.EN=1;										// enable CLC system
	// config interrupt
	IPR5bits.CLC2IP=1;										// CLC1 is high priority
	PIR5bits.CLC2IF=0;										// CLC1 interrupt flags clear
	PIE5bits.CLC2IE=0;										// enable interrupt for CLC1	
}
//
//*************************************************************
//*** CLC1 INTERRUPT ******************************************
//*************************************************************
//
void __interrupt(irq(IRQ_CLC1),high_priority, base(8)) CLC1_vect_isr()
{   

	if(RW_GET)			// READ
	{
		if(A1_GET)
		{
			if(A0_GET)	// $D013 (DSOCR)
			{
				// JUST PIA CONFIG, SO DO NOTHING
			}
			else		// $D012 (DSP)
			{
				DATA_SET = (U1FIFObits.TXBF) ? 0x80 : 0x00;
			}
		}
		else
		{
			if(A0_GET)	// $D011 (KBDCR)
			{
				DATA_SET = kbhit() ? 0x80 : 0x00;
			}
			else		// $D010 (KBD)
			{
				DATA_SET = kbhit() ? (getch() | 0x80) : 0x00;					
			}			
		}
		DATA_DIR=0x00;
	}
	else				// WRITE
	{
		if(A1_GET)
		{
			if(A0_GET)	// $D013 (DSOCR)
			{
				// JUST PIA CONFIG, SO DO NOTHING
			}
			else		// $D012 (DSP)
			{
				if(!U1FIFObits.TXBF)
				{
					U1TXB=DATA_GET & 0x7F;				
				}
			}
		}
		else
		{
			if(A0_GET)	// $D011 (KBDCR)
			{
				// NEVER WRITES TO KBDCR, SO DO NOTHING HERE
			}
			else		// $D010 (KBD)
			{
				// NEVER WRITES TO KBD, SO DO NOTHING HERE
			}			
		}		
	}
	PIR0bits.CLC1IF=0;										// clear interrupt flag
 	CLCSELECTbits.SLCT=0b01;								// select CLC2
	CLCnPOLbits.POL=1;										// output of logic cell not inverted
	CLCnPOLbits.POL=0;										// output of logic cell not inverted
	DATA_DIR=0xFF;	
}
//
//*************************************************************
//*** END *****************************************************
//*************************************************************

