//*************************************************************
//***	FILE:		UART1.C									***
//***	DATE:		28/09/21								***
//***	AUTHOR:		GEOFFREY SWALES							***
//***	COMPANY:	BULK AIR LIMITED						***
//***	VERSION:	V1.0									***
//*************************************************************
//***	DESCRIPTION:										***
//***	UART 1 ROUTINES FOR BULK AIR ENGINE HARDWARE		***
//*************************************************************
//***	VERSION TRACK:										***
//***	V0.1: INITIAL DEVELOPMENT VERSION					***
//***	V1.0: WORKING PRODUCTION RELEASE					***
//*************************************************************
//
//*************************************************************
//*** INCLUDE REQUIRED SPECIFIC DEFINTIONS ********************
//*************************************************************
//
#include <xc.h>
#include "uart1.h"
#include "interrupt_manager.h"
#include "PIPE.h"
//
//*************************************************************
//*** GLOBAL VARIABLES ****************************************
//*************************************************************
//
_pipe_buffer uart_1_tx_buffer[UART1_TX_BUFF_SIZE];			// pipe buffer to hold data for uart 1 tx
_pipe_header uart_1_tx_pipe;								// pipe header for uart 1 tx pipe
//
_pipe_buffer uart_1_rx_buffer[UART1_RX_BUFF_SIZE];			// pipe buffer to hold data for uart 1 rx
_pipe_header uart_1_rx_pipe;								// pipe header for uart 1 rx pipe
//
//*************************************************************
//*** INITIALISE UART *****************************************
//*************************************************************
//
void uart_1_init(void)										// initialise uart1 hardware
{
	pipe_init(&uart_1_tx_pipe,uart_1_tx_buffer,sizeof(uart_1_tx_buffer));// initialise uart 1 tx pipe
	pipe_init(&uart_1_rx_pipe,uart_1_rx_buffer,sizeof(uart_1_rx_buffer));// initialise uart 1 rx pipe
    // Disable interrupts before changing states
    PIE4bits.U1RXIE = 0;
    PIE4bits.U1TXIE = 0;
    PIE4bits.U1EIE = 0;	
	//
	//*** TX PIN ***
	PORTAbits.RA0=1;			// TX line taken high
	TRISAbits.TRISA0=0;			// TX line is an output (USB UART RX)
	RA0PPS = 0x10;				// RA0 MAPPED TO TX1	 
	//
	//*** RX PIN ***
	TRISAbits.TRISA3=1;			// RX line is input (USB UART TX)
	U1RXPPS = 0b000011;			// U1RX=PORTA PIN 3
	//
	//*** CTS PIN ***
	TRISAbits.TRISA1=0;			// #cts line is an output
	RA1PPS=0x00;				// CTS LINE OUTPUT AS IO PIN
	PORTAbits.RA1=0;			// always Clear To Send
	
	
    // Set the UART1 module to the options selected in the user interface.

    // P1L 0; 
    U1P1L = 0x00;
    U1P1H = 0x00;
    U1P2L = 0x00;
    U1P2H = 0x00;
    U1P3L = 0x00;
    U1P3H = 0x00;
//
	U1CON0=0x00;			// clear all settings
	U1CON0bits.BRGS=1;		// high speed BAUD clock
	U1CON0bits.TXEN=1;		// tx is enabled
	U1CON0bits.RXEN=1;		// rx is enabled
//
	U1CON1=0x00;			// clear all settings here
	U1CON1bits.ON=1;		// serial port enabled
//	U1CON2bits.U1FLO=0b10;	// RTS, CTS flow control
//
	U1CON2=0x00;			// clear all settings
	U1CON2bits.RUNOVF=1;	// rx continues to synchronise after overflow
//
    U1BRGL = 0x8A;			// baud rate of 115200
    U1BRGH = 0x00;			// baud rate of 115200
//
    // STPMD in middle of first Stop bit; TXWRE No error; 
    U1FIFO = 0x00;
    // ABDIF Auto-baud not enabled or not complete; WUIF WUE not enabled by software; ABDIE disabled; 
    U1UIR = 0x00;
    // ABDOVF overflowed; TXCIF 0; RXBKIF No Break detected; RXFOIF overflowed; CERIF No Checksum error; 
    U1ERRIR = 0x22;
    // TXCIE disabled; FERIE disabled; TXMTIE disabled; ABDOVE disabled; CERIE disabled; RXFOIE disabled; PERIE disabled; RXBKIE disabled; 
    U1ERRIE = 0x00;
	
    // Assign peripheral interrupt priority vectors
    IPR4bits.U1TXIP = 0;
    IPR4bits.U1EIP = 0;
    IPR4bits.U1RXIP = 0;
	
	
	
	
    // enable receive interrupt
    PIE4bits.U1RXIE = 1;
    // enable error interrupt
    PIE4bits.U1EIE = 1;
}
//
//*************************************************************
//*** RETURNS NUMBER OF BYTES RECEIVED ************************
//*************************************************************
//
void putch(unsigned char byte)
{
	uart_1_put((uint8_t)byte);	
}
//
//*************************************************************
//*** RETURNS NUMBER OF BYTES RECEIVED ************************
//*************************************************************
//
bool uart_1_kbhit(void)									// returns number of bytes waiting in rx pipe
{
	if(pipe_data(&uart_1_rx_pipe))						// return amount of data in rx pipe
	{
		return(true);
	}
	return(false);
}
//
//*************************************************************
//*** GET BYTE FROM RECEIVER BUFFER ***************************
//*************************************************************
//
uint8_t uart_1_get(void)									// returns byte from receiver buffer
{
	uint8_t b=0;
	PIE4bits.U1RXIE = 0;
	if(pipe_data(&uart_1_rx_pipe))							// only if there is data in the rx pipe
	{
		b=pipe_get(&uart_1_rx_pipe);					// return byte from rx pipe
		if(pipe_data(&uart_1_rx_pipe)<=(UART1_RX_BUFF_SIZE/4))							// only if there is data in the rx pipe
		{
			PORTAbits.RA1=0;	// take RTS line low to enable data		
		}
	}
	PIE4bits.U1RXIE = 1;
	return(b);												// no data to just return zero
}
//
//*************************************************************
//*** PUT BYTE INTO TRANSMITTER BUFFER ************************
//*************************************************************
//
void uart_1_put(uint8_t d)									// puts byte into transmitter buffer
{
	PIE4bits.U1TXIE = 0;
	if(pipe_space(&uart_1_tx_pipe))							// only if there is space in the tx pipe...
	{
		pipe_put(&uart_1_tx_pipe,d);						// put byte into tx pipe
	}
	PIE4bits.U1TXIE = 1;
}
//
//*************************************************************
//*** SERVICES TRANSMITTER INTERRUPT **************************
//*************************************************************
//
void __interrupt(irq(U1TX),base(8)) UART_tx_vect_isr()
{   
	if(pipe_data(&uart_1_tx_pipe))
	{
		U1TXB=pipe_get(&uart_1_tx_pipe);
	}
    else
    {
        PIE4bits.U1TXIE = 0;
    }
}
//
//*************************************************************
//*** SERVICES RECEIVER INTERRUPT *****************************
//*************************************************************
//
void __interrupt(irq(U1RX),base(8)) UART1_rx_vect_isr()
{
	while(!U1FIFObits.RXBE)
	{
		uint8_t b=U1RXB;
		if(pipe_space(&uart_1_rx_pipe))							// only if there is space in the tx pipe...
		{
			pipe_put(&uart_1_rx_pipe,b);						// put byte into tx pipe
		}
		if(pipe_space(&uart_1_rx_pipe)<=(UART1_RX_BUFF_SIZE/4))
		{
			PORTAbits.RA1=1;	// take RTS line high to stop data
		}
	}
	U1ERRIRbits.U1RXFOIF=0;
}
//
//*************************************************************
//*** SERVICES FAULT INTERRUPT ********************************
//*************************************************************
//
void __interrupt(irq(U1E),base(8)) UART1_framing_err_vect_isr()
{
    U1ERRIR = 0;
}
//
//*************************************************************
//*** END OF FILE *********************************************
//*************************************************************
//
