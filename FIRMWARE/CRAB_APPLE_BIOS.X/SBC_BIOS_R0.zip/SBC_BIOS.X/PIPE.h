//*************************************************************
//***	FILE:		RTOS_PIPE.H			    ***
//***	DATE:		09/09/21			    ***
//***	AUTHOR:		GEOFFREY SWALES			    ***
//***	VERSION:	V0.1				    ***
//*************************************************************
//***	DESCRIPTION:					    ***
//***	SIMPLE PROTOTHREADS				    ***
//*************************************************************
//***	VERSION TRACK:					    ***
//***	V0.1: INITIAL DEVELOPMENT VERSION		    ***
//***	V1.0:						    ***
//*************************************************************
//
//
//*************************************************************
//*** REDEFINITION BLOCKING ***********************************
//*************************************************************
//
#ifndef _RTOS_PIPE2_H_					    // if not defined already
#define	_RTOS_PIPE2_H_					    // define it so we don't do it again
//
//*************************************************************
//*** INCLUDE USEFUL COMPILER DEFINTIONS **********************
//*************************************************************
//
#include <xc.h>						    // lots of useful definitions for xc16 compiler
#include <stdint.h>					    // nice standard variable definitions used in this file
#include <stdbool.h>
//
//*************************************************************
//*** USEFUL DEFINITIONS **************************************
//*************************************************************
//

//
//*************************************************************
//*** DECLARE ANY EXTERNAL GLOBAL VARIABLES *******************
//*************************************************************
//

//
//*************************************************************
//*** STRUCTURE DEFINITIONS ***********************************
//*************************************************************
//
typedef uint8_t _pipe_buffer;                                      // new type for pipe buffer
//
typedef struct _pipe_header				    // pipe header structure
{
    uint16_t size;					    // size of the pipe buffer
    uint16_t in;					    // pointer for the next byte into the buffer
    uint16_t out;					    // pointer for the next byte out of the buffer
    uint8_t * buffer;					    // the pipe buffer
}_pipe_header;
//
//*************************************************************
//*** PROTOTYPE FUNCTIONS *************************************
//*************************************************************
//
void pipe_init(_pipe_header * h, _pipe_buffer * b, uint16_t s);
void pipe_reset(_pipe_header * h);
void pipe_put(_pipe_header * h, uint8_t d);
uint8_t pipe_get(_pipe_header * h);
uint16_t pipe_data(_pipe_header * h);
uint16_t pipe_space(_pipe_header * h);
void pipe_read(_pipe_header * h, uint8_t * obj, uint16_t len);
void pipe_write(_pipe_header * h,uint8_t * obj, uint16_t len);
//
//*************************************************************
//*** MACROS TO MAKE LIFE EASIER ******************************
//*************************************************************
//

//
//*************************************************************
//*** END OF REDEFINITION BLOCKING ****************************
//*************************************************************
//
#endif														// end of redefine blocking
//
//*************************************************************
//*** END OF FILE *********************************************
//*************************************************************
//

