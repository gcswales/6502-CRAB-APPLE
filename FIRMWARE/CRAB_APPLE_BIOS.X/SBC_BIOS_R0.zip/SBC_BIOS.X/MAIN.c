//*************************************************************
//***	FILE:		MAIN.C									***
//***	DATE:		26/09/22								***
//***	AUTHOR:		GEOFFREY SWALES							***
//***	VERSION:	V0.1									***
//*************************************************************
//***	DESCRIPTION:										***
//*************************************************************
//***	VERSION TRACK:										***
//***	V0.1: INITIAL DEVELOPMENT VERSION					***
//***	V1.0:												***
//*************************************************************
//	
//*************************************************************
//*** INCLUDE REQUIRED SPECIFIC DEFINTIONS ********************
//*************************************************************
//
#include "device_config.h"
#include <xc.h>
#include "PIPE.h"
#include "device_config.h"
#include "interrupt_manager.h"
#include "mcc.h"
#include "pin_manager.h"
#include "uart1.h"
//
//*************************************************************
//*** STRUCTURE DEFINITIONS ***********************************
//*************************************************************
//

//
//*************************************************************
//*** GLOBAL VARIABLES ****************************************
//*************************************************************
//
uint8_t byte_out=0;
//
//*************************************************************
//*** DEFINITIONS *********************************************
//*************************************************************
//
#define ASCII_ESC		27
#define	BIOS_VERSION	1
#define CLKREF_500kHZ	0x7
#define CLKREF_1MHZ		0x6
#define CLKREF_2MHZ		0x5
#define CLKREF_4MHZ		0x4
#define CLKREF_8MHZ		0x3
//
//*************************************************************
//*** FUNCTION PROTOTYPES *************************************
//*************************************************************
//
void print_title(void);										// prints BIOS title screen
void reset_init(void);
void clc1_init(void);
void clc2_init(void);
void clc3_init(void);
void clc4_init(void);
void clock_init(void);
//
//*************************************************************
//*** CONFIGURE FUSES *****************************************
//*************************************************************
//
// CONFIG1
#pragma config FEXTOSC = OFF    // External Oscillator Selection->Oscillator not enabled
#pragma config RSTOSC = HFINTOSC_64MHZ    // Reset Oscillator Selection->HFINTOSC with HFFRQ = 64 MHz and CDIV = 1:1
// CONFIG2
#pragma config CLKOUTEN = OFF    // Clock out Enable bit->CLKOUT function is disabled
#pragma config PR1WAY = ON    // PRLOCKED One-Way Set Enable bit->PRLOCKED bit can be cleared and set only once
#pragma config CSWEN = ON    // Clock Switch Enable bit->Writing to NOSC and NDIV is allowed
#pragma config FCMEN = OFF    // Fail-Safe Clock Monitor Enable bit->Fail-Safe Clock Monitor disabled
// CONFIG3
#pragma config MCLRE = INTMCLR    // MCLR Enable bit->If LVP = 0, MCLR pin function is port defined function; If LVP =1, RE3 pin fuction is MCLR
#pragma config PWRTS = PWRT_1    // Power-up timer selection bits->PWRT set at 1ms
#pragma config MVECEN = ON    // Multi-vector enable bit->Multi-vector enabled, Vector table used for interrupts
#pragma config IVT1WAY = ON    // IVTLOCK bit One-way set enable bit->IVTLOCKED bit can be cleared and set only once
#pragma config LPBOREN = OFF    // Low Power BOR Enable bit->Low-Power BOR disabled
#pragma config BOREN = SBORDIS    // Brown-out Reset Enable bits->Brown-out Reset enabled , SBOREN bit is ignored
// CONFIG4
#pragma config BORV = VBOR_1P9    // Brown-out Reset Voltage Selection bits->Brown-out Reset Voltage (VBOR) set to 1.9V
#pragma config ZCD = OFF    // ZCD Disable bit->ZCD module is disabled. ZCD can be enabled by setting the ZCDSEN bit of ZCDCON
#pragma config PPS1WAY = ON    // PPSLOCK bit One-Way Set Enable bit->PPSLOCKED bit can be cleared and set only once; PPS registers remain locked after one clear/set cycle
#pragma config STVREN = ON    // Stack Full/Underflow Reset Enable bit->Stack full/underflow will cause Reset
#pragma config LVP = OFF    // Low Voltage Programming Enable bit->HV on MCLR/VPP must be used for programming
#pragma config XINST = OFF    // Extended Instruction Set Enable bit->Extended Instruction Set and Indexed Addressing Mode disabled
// CONFIG5
#pragma config WDTCPS = WDTCPS_31    // WDT Period selection bits->Divider ratio 1:65536; software control of WDTPS
#pragma config WDTE = OFF    // WDT operating mode->WDT Disabled; SWDTEN is ignored
// CONFIG6
#pragma config WDTCWS = WDTCWS_6    // WDT Window Select bits->window always open (100%); no software control; keyed access required
#pragma config WDTCCS = LFINTOSC    // WDT input clock selector->WDT reference clock is the 31.0 kHz LFINTOSC
// CONFIG7
#pragma config BBSIZE = BBSIZE_512    // Boot Block Size selection bits->Boot Block size is 512 words
#pragma config BBEN = OFF    // Boot Block enable bit->Boot block disabled
#pragma config SAFEN = OFF    // Storage Area Flash enable bit->SAF disabled
#pragma config DEBUG = OFF    // Background Debugger->Background Debugger disabled
// CONFIG8
#pragma config WRTB = OFF    // Boot Block Write Protection bit->Boot Block not Write protected
#pragma config WRTC = OFF    // Configuration Register Write Protection bit->Configuration registers not Write protected
#pragma config WRTD = OFF    // Data EEPROM Write Protection bit->Data EEPROM not Write protected
#pragma config WRTSAF = OFF    // SAF Write protection bit->SAF not Write Protected
#pragma config WRTAPP = OFF    // Application Block write protection bit->Application Block not write protected
// CONFIG10
#pragma config CP = OFF    // PFM and Data EEPROM Code Protection bit->PFM and Data EEPROM code protection disabled
//
//*************************************************************
//*** MAIN ROUTINE ********************************************
//*************************************************************
//
void main(void)
{
    system_init();
	uart_1_init();
    // Enable high priority global interrupts
    INTERRUPT_GlobalInterruptHighEnable();
    // Enable low priority global interrupts.
    INTERRUPT_GlobalInterruptLowEnable();
	//print_title();
//	clc1_init();
//	clc2_init();
//	clc3_init();
//	clc4_init();
//	reset_init();
	while(1)
	{
		if(!PORTAbits.RA5) RESET();							// if reset line is pulled low, reset
	}
}
//
//*************************************************************
//*** INITIALISE CONFIGURATION LOGIC **************************
//*************************************************************
//
void clock_init(void)
{
//
	MD1CON0bits.EN=0;										// disable MSD
	MD1CON1bits.CHSYNC=0;									// high line synchronisation
	MD1CON1bits.CLSYNC=1;									// low line synchronisation	
	MD1CARHbits.MD1CH=0b1101;								// MSD high carrier input is CLC4_OUT (SOFTWARE CONTROLLED!)
	MD1CARLbits.MD1CL=0b0100;								// MSD low carrier input is CLKREF output
	MD1SRCbits.MS=0b01100;									// MSD source input is CLC1_OUT
	MD1CON0bits.OPOL=0;										// output not inverted
	MD1CON0bits.EN=1;										// enable MSD
//
	CLKRCONbits.EN=0;										// disable system clock
	CLKRCLK = 0b0000;										// Fosc as reference clock source
	CLKRCONbits.DIV=CLKREF_1MHZ;							// clock frequency of 1MHz
	CLKRCONbits.DC=0b10;									// 50% duty cycle
	CLKRCONbits.EN=1;										// 1=enable, 0=disable system clock
//	
}
//
//*************************************************************
//*** INITIALISE CONFIGURATION LOGIC **************************
//*************************************************************
//
void clc1_init(void)
{
	CLCSELECTbits.SLCT=0b00;								// select CLC1
	// disable gate
	CLCnCONbits.EN=0;										// disable gate while we configure it
	// data selection
	CLCnSEL0bits.D1S=0;										// select CLCIN0PPS for input 0 (ROM_CS)
	CLCnSEL1bits.D2S=1;										// select CLCIN1PPS for input 1 (IO_CS)
	CLCnSEL2bits.D3S=2;										// select CLCIN2PPS for input 2 (ENABLE)
	CLCnSEL3bits.D4S=3;										// select CLCIN3PPS for input 3 (R/#W)
	// data gate 1 - ROM_CS = 0
	CLCnGLS0bits.G1D1N=0;									// input 1 negated
	CLCnGLS0bits.G1D1T=1;									// no other input selection
	CLCnGLS0bits.G1D2N=0;									// no other input selection
	CLCnGLS0bits.G1D2T=1;									// no other input selection
	CLCnGLS0bits.G1D3N=1;									// no other input selection
	CLCnGLS0bits.G1D3T=0;									// no other input selection
	CLCnGLS0bits.G1D4N=0;									// no other input selection
	CLCnGLS0bits.G1D4T=0;									// no other input selection
	CLCnPOLbits.G1POL=1;									// output of gate 1 not inverted
	// data gate 2 - IO_CS = 0
	CLCnGLS1bits.G2D1N=0;									// no other input selection
	CLCnGLS1bits.G2D1T=0;									// no other input selection
	CLCnGLS1bits.G2D2N=0;									// input 2 negated
	CLCnGLS1bits.G2D2T=0;									// no other input selection
	CLCnGLS1bits.G2D3N=0;									// no other input selection
	CLCnGLS1bits.G2D3T=0;									// no other input selection
	CLCnGLS1bits.G2D4N=0;									// no other input selection
	CLCnGLS1bits.G2D4T=0;									// no other input selection
	CLCnPOLbits.G2POL=1;									// output of gate 2 not inverted
	// data gate 3 - EN = 1
	CLCnGLS2bits.G3D1N=0;									// no other input selection
	CLCnGLS2bits.G3D1T=0;									// no other input selection
	CLCnGLS2bits.G3D2N=0;									// no other input selection
	CLCnGLS2bits.G3D2T=0;									// no other input selection
	CLCnGLS2bits.G3D3N=0;									// no other input selection
	CLCnGLS2bits.G3D3T=0;									// input 3 true
	CLCnGLS2bits.G3D4N=0;									// no other input selection
	CLCnGLS2bits.G3D4T=0;									// no other input selection
	CLCnPOLbits.G3POL=1;									// output of gate 3 not inverted
	// data gate 4 - A0 = 1
	CLCnGLS3bits.G4D1N=0;									// no other input selection
	CLCnGLS3bits.G4D1T=0;									// no other input selection
	CLCnGLS3bits.G4D2N=0;									// no other input selection
	CLCnGLS3bits.G4D2T=0;									// no other input selection
	CLCnGLS3bits.G4D3N=0;									// no other input selection
	CLCnGLS3bits.G4D3T=0;									// no other input selection
	CLCnGLS3bits.G4D4N=0;									// no other input selection
	CLCnGLS3bits.G4D4T=0;									// input 4 true
	CLCnPOLbits.G4POL=1;									// output of gate 4 not inverted
	// set logic gate
	CLCnCONbits.MODE=0b010;									// 4-input AND gate
	// logic output polarity
	CLCnPOLbits.POL=0;										// output of logic cell not inverted
	// set logic output interrupts
	CLCnCONbits.INTP=0;										// interrupt on rising edge
	CLCnCONbits.INTN=1;										// nointerrupt on falling edge
	// finished so enable the gate
	CLCnCONbits.EN=1;										// enable CLC system
	// config interrupt
	IPR0bits.CLC1IP=1;										// CLC1 is high priority
	PIR0bits.CLC1IF=0;										// CLC1 interrupt flags clear
	PIE0bits.CLC1IE=0;										// enable interrupt for CLC1
}
//
//*************************************************************
//*** INITIALISE CONFIGURATION LOGIC **************************
//*************************************************************
//
void clc2_init(void)
{
	CLCSELECTbits.SLCT=0b01;								// select CLC2
	// disable gate
	CLCnCONbits.EN=0;										// disable gate while we configure it
	// data selection
	CLCnSEL0bits.D1S=34;									// select CLCIN0PPS for input CLC1_OUT (CS)
	CLCnSEL1bits.D2S=3;										// select CLCIN3PPS for input 1 (R/#W)
	CLCnSEL2bits.D3S=2;										// N/C
	CLCnSEL3bits.D4S=3;										// N/C
	// data gate 1 - READ
	CLCnGLS0bits.G1D1N=1;									// CS=1
	CLCnGLS0bits.G1D1T=0;									// no other input selection
	CLCnGLS0bits.G1D2N=1;									// R/#W = 1
	CLCnGLS0bits.G1D2T=0;									// no other input selection
	CLCnGLS0bits.G1D3N=0;									// no other input selection
	CLCnGLS0bits.G1D3T=0;									// no other input selection
	CLCnGLS0bits.G1D4N=0;									// no other input selection
	CLCnGLS0bits.G1D4T=0;									// no other input selection
	CLCnPOLbits.G1POL=1;									// invert output for AND
	// data gate 2 - NOT USED JUST OUTPUTS 1
	CLCnGLS1bits.G2D1N=0;									// no other input selection
	CLCnGLS1bits.G2D1T=0;									// no other input selection
	CLCnGLS1bits.G2D2N=0;									// input 2 negated
	CLCnGLS1bits.G2D2T=0;									// no other input selection
	CLCnGLS1bits.G2D3N=0;									// no other input selection
	CLCnGLS1bits.G2D3T=0;									// no other input selection
	CLCnGLS1bits.G2D4N=0;									// no other input selection
	CLCnGLS1bits.G2D4T=0;									// no other input selection
	CLCnPOLbits.G2POL=1;									// output of gate 2 not inverted
	// data gate 3 - NOT USED JUST OUTPUTS 1
	CLCnGLS2bits.G3D1N=0;									// no other input selection
	CLCnGLS2bits.G3D1T=0;									// no other input selection
	CLCnGLS2bits.G3D2N=0;									// no other input selection
	CLCnGLS2bits.G3D2T=0;									// no other input selection
	CLCnGLS2bits.G3D3N=0;									// no other input selection
	CLCnGLS2bits.G3D3T=0;									// input 3 true
	CLCnGLS2bits.G3D4N=0;									// no other input selection
	CLCnGLS2bits.G3D4T=0;									// no other input selection
	CLCnPOLbits.G3POL=1;									// output of gate 3 not inverted
	// data gate 4 - NOT USED JUST OUTPUTS 1
	CLCnGLS3bits.G4D1N=0;									// no other input selection
	CLCnGLS3bits.G4D1T=0;									// no other input selection
	CLCnGLS3bits.G4D2N=0;									// no other input selection
	CLCnGLS3bits.G4D2T=0;									// no other input selection
	CLCnGLS3bits.G4D3N=0;									// no other input selection
	CLCnGLS3bits.G4D3T=0;									// no other input selection
	CLCnGLS3bits.G4D4N=0;									// no other input selection
	CLCnGLS3bits.G4D4T=0;									// input 4 true
	CLCnPOLbits.G4POL=1;									// output of gate 4 not inverted
	// set logic gate
	CLCnCONbits.MODE=0b010;									// 4-input AND gate
	// logic output polarity
	CLCnPOLbits.POL=0;										// output of logic cell not inverted
	// set logic output interrupts
	CLCnCONbits.INTP=1;										// interrupt on rising edge
	CLCnCONbits.INTN=0;										// nointerrupt on falling edge
	// finished so enable the gate
	CLCnCONbits.EN=1;										// enable CLC system
	// config interrupt
	IPR5bits.CLC2IP=1;										// CLC2 is high priority
	PIR5bits.CLC2IF=0;										// CLC2 interrupt flags clear
	PIE5bits.CLC2IE=1;										// enable interrupt for CLC2
}
//
//*************************************************************
//*** INITIALISE CONFIGURATION LOGIC **************************
//*************************************************************
//
void clc3_init(void)
{
	CLCSELECTbits.SLCT=0b10;								// select CLC3
	// disable gate
	CLCnCONbits.EN=0;										// disable gate while we configure it
	// data selection
	CLCnSEL0bits.D1S=34;									// select CLCIN0PPS for input CLC1_OUT (CS)
	CLCnSEL1bits.D2S=3;										// select CLCIN3PPS for input 1 (R/#W)
	CLCnSEL2bits.D3S=2;										// N/C
	CLCnSEL3bits.D4S=3;										// N/C
	// data gate 1 - WRITE
	CLCnGLS0bits.G1D1N=1;									// CS=1
	CLCnGLS0bits.G1D1T=0;									// no other input selection
	CLCnGLS0bits.G1D2N=0;									// no other input selection
	CLCnGLS0bits.G1D2T=1;									// R/#W = 0
	CLCnGLS0bits.G1D3N=0;									// no other input selection
	CLCnGLS0bits.G1D3T=0;									// no other input selection
	CLCnGLS0bits.G1D4N=0;									// no other input selection
	CLCnGLS0bits.G1D4T=0;									// no other input selection
	CLCnPOLbits.G1POL=1;									// invert output for AND
	// data gate 2 - NOT USED JUST OUTPUTS 1
	CLCnGLS1bits.G2D1N=0;									// no other input selection
	CLCnGLS1bits.G2D1T=0;									// no other input selection
	CLCnGLS1bits.G2D2N=0;									// input 2 negated
	CLCnGLS1bits.G2D2T=0;									// no other input selection
	CLCnGLS1bits.G2D3N=0;									// no other input selection
	CLCnGLS1bits.G2D3T=0;									// no other input selection
	CLCnGLS1bits.G2D4N=0;									// no other input selection
	CLCnGLS1bits.G2D4T=0;									// no other input selection
	CLCnPOLbits.G2POL=1;									// output of gate 2 not inverted
	// data gate 3 - NOT USED JUST OUTPUTS 1
	CLCnGLS2bits.G3D1N=0;									// no other input selection
	CLCnGLS2bits.G3D1T=0;									// no other input selection
	CLCnGLS2bits.G3D2N=0;									// no other input selection
	CLCnGLS2bits.G3D2T=0;									// no other input selection
	CLCnGLS2bits.G3D3N=0;									// no other input selection
	CLCnGLS2bits.G3D3T=0;									// input 3 true
	CLCnGLS2bits.G3D4N=0;									// no other input selection
	CLCnGLS2bits.G3D4T=0;									// no other input selection
	CLCnPOLbits.G3POL=1;									// output of gate 3 not inverted
	// data gate 4 - NOT USED JUST OUTPUTS 1
	CLCnGLS3bits.G4D1N=0;									// no other input selection
	CLCnGLS3bits.G4D1T=0;									// no other input selection
	CLCnGLS3bits.G4D2N=0;									// no other input selection
	CLCnGLS3bits.G4D2T=0;									// no other input selection
	CLCnGLS3bits.G4D3N=0;									// no other input selection
	CLCnGLS3bits.G4D3T=0;									// no other input selection
	CLCnGLS3bits.G4D4N=0;									// no other input selection
	CLCnGLS3bits.G4D4T=0;									// input 4 true
	CLCnPOLbits.G4POL=1;									// output of gate 4 not inverted
	// set logic gate
	CLCnCONbits.MODE=0b010;									// 4-input AND gate
	// logic output polarity
	CLCnPOLbits.POL=0;										// output of logic cell not inverted
	// set logic output interrupts
	CLCnCONbits.INTP=1;										// interrupt on rising edge
	CLCnCONbits.INTN=0;										// nointerrupt on falling edge
	// finished so enable the gate
	CLCnCONbits.EN=1;										// enable CLC system
	// config interrupt
	IPR7bits.CLC3IP=1;										// CLC3 is high priority
	PIR7bits.CLC3IF=0;										// CLC3 interrupt flags clear
	PIE7bits.CLC3IE=1;										// enable interrupt for CLC3
}
//
//*************************************************************
//*** INITIALISE CONFIGURATION LOGIC **************************
//*************************************************************
//
void clc4_init(void)
{
	CLCSELECTbits.SLCT=0b11;								// select CLC4
	// disable gate
	CLCnCONbits.EN=0;										// disable gate while we configure it
	// data selection
	CLCnSEL0bits.D1S=0;										// N/C
	CLCnSEL1bits.D2S=1;										// N/C
	CLCnSEL2bits.D3S=2;										// N/C
	CLCnSEL3bits.D4S=3;										// N/C
	// data gate 1 - ROM_CS,IO_CS,EN for LATCH EN
	CLCnGLS0bits.G1D1N=0;									// input 1 negated
	CLCnGLS0bits.G1D1T=0;									// no other input selection
	CLCnGLS0bits.G1D2N=0;									// no other input selection
	CLCnGLS0bits.G1D2T=0;									// no other input selection
	CLCnGLS0bits.G1D3N=0;									// no other input selection
	CLCnGLS0bits.G1D3T=0;									// no other input selection
	CLCnGLS0bits.G1D4N=0;									// no other input selection
	CLCnGLS0bits.G1D4T=0;									// no other input selection
	CLCnPOLbits.G1POL=1;									// output of gate 1 not inverted
	// data gate 2 - A0=0
	CLCnGLS1bits.G2D1N=0;									// no other input selection
	CLCnGLS1bits.G2D1T=0;									// no other input selection
	CLCnGLS1bits.G2D2N=0;									// input 2 negated
	CLCnGLS1bits.G2D2T=0;									// no other input selection
	CLCnGLS1bits.G2D3N=0;									// no other input selection
	CLCnGLS1bits.G2D3T=0;									// no other input selection
	CLCnGLS1bits.G2D4N=0;									// no other input selection
	CLCnGLS1bits.G2D4T=0;									// no other input selection
	CLCnPOLbits.G2POL=1;									// output of gate 2 not inverted
	// data gate 3 - NOT (ROM_CS, IO_CS, EN) forms LATCH RESET
	CLCnGLS2bits.G3D1N=0;									// no other input selection
	CLCnGLS2bits.G3D1T=0;									// no other input selection
	CLCnGLS2bits.G3D2N=0;									// no other input selection
	CLCnGLS2bits.G3D2T=0;									// no other input selection
	CLCnGLS2bits.G3D3N=0;									// no other input selection
	CLCnGLS2bits.G3D3T=0;									// input 3 true
	CLCnGLS2bits.G3D4N=0;									// no other input selection
	CLCnGLS2bits.G3D4T=0;									// no other input selection
	CLCnPOLbits.G3POL=1;									// output of gate 3 not inverted
	// data gate 4 - NO LATCH SET
	CLCnGLS3bits.G4D1N=0;									// no other input selection
	CLCnGLS3bits.G4D1T=0;									// no other input selection
	CLCnGLS3bits.G4D2N=0;									// no other input selection
	CLCnGLS3bits.G4D2T=0;									// no other input selection
	CLCnGLS3bits.G4D3N=0;									// no other input selection
	CLCnGLS3bits.G4D3T=0;									// no other input selection
	CLCnGLS3bits.G4D4N=0;									// no other input selection
	CLCnGLS3bits.G4D4T=0;									// input 4 true
	CLCnPOLbits.G4POL=1;									// output of gate 4 not inverted
	// set logic gate
	CLCnCONbits.MODE=0b010;									// 4-input AND gate
	// logic output polarity
	CLCnPOLbits.POL=0;										// output of logic cell not inverted
	// set logic output interrupts
	CLCnCONbits.INTP=1;										// interrupt on rising edge
	CLCnCONbits.INTN=0;										// nointerrupt on falling edge
	// finished so enable the gate
	CLCnCONbits.EN=1;										// enable CLC system	
	//
	// config interrupt
	IPR8bits.CLC4IP=1;										// CLC4 is high priority
	PIR8bits.CLC4IF=0;										// CLC4 interrupt flags clear
	PIE8bits.CLC4IE=0;										// enable interrupt for CLC4
}
//
//*************************************************************
//*** INITIALISE RESET LINE ***********************************
//*************************************************************
//
void reset_init(void)
{
	__delay_ms(5);											// wait for any button debounce to pass
	while(!PORTAbits.RA5);									// wait until RESET line goes high (button released)
	__delay_ms(5);											// wait for any button debounce to pass
	//	U1TXB='R';
	PORTAbits.RA5=0;
	TRISAbits.TRISA5=0;										// reset line in an output (pulled low)
	__delay_us(50);											// wait for any button debounce to pass
	clock_init();
	CLCSELECTbits.SLCT=0b11;								// select CLC4
	CLCnPOLbits.POL=1;										// output of logic cell not inverted
	CLCnPOLbits.POL=0;										// output of logic cell not inverted
	__delay_us(50);											// wait for any button debounce to pass
	PORTAbits.RA5=1;
	__delay_us(10);											// keep low for 50ms
	TRISAbits.TRISA5=1;										// reset line in an input, pull high

}
//
//*************************************************************
//*** PRINT BIOS TITLE SCREEN *********************************
//*************************************************************
//
void print_title(void)
{
	uint8_t a=BIOS_VERSION/10;
	uint8_t b=BIOS_VERSION%10;
	printf( "%c[2J",ASCII_ESC );							// clear the screen
	printf( "%c[H",ASCII_ESC );								// move cursor home
	printf( "%c[1m",ASCII_ESC );							// set text bright
	__delay_ms(500);
	printf( "%c[37m   __ ___  __ ___   ___ ___ ___  ___ \r\n",ASCII_ESC);
	printf( "%c[36m  / /| __|/  \\_  ) | _ )_ _/ _ \\/ __|\r\n",ASCII_ESC);
	printf( "%c[36m / _ \\__ \\ () / /  | _ \\| | (_) \\__ \\\r\n",ASCII_ESC);
	printf( "%c[34m \\___/___/\\__/___| |___/___\\___/|___/\r\n",ASCII_ESC);	
	printf( "%c[34m V%u.%u  COPYRIGHT 1975 GEOFFREY SWALES \r\n",ASCII_ESC, a,b );
	printf( "%c[32m\r\n",ASCII_ESC);						// set text green
}
//
//*************************************************************
//*** CLC1 INTERRUPT ******************************************
//*************************************************************
// NOT USED
void __interrupt(irq(CLC1),high_priority, base(8)) CLC1_vect_isr()
{   
//	TRISC=0xFF;
	PIR0bits.CLC1IF=0;										// clear interrupt flag
}
//
//*************************************************************
//*** CLC2 INTERRUPT ******************************************
//*************************************************************
// 6502 READS BYTE FROM UART
void __interrupt(irq(CLC2),high_priority,base(8)) CLC2_vect_isr()
{   
//	static uint8_t b=0;
//	TRISC=0x00;
//	if(PORTBbits.RB7)										// A0=1, KBDCR
//	{
//		if(!U1FIFObits.RXBE)								// if keyboard data
//		{
//			U1TXB='1';
//			//TRISC=0b10000000;								// set D7
//			b=U1RXB | 0b10000000;							// set D7
//		}
//		else												// no keyboard data
//		{
//			U1TXB='2';
//			//TRISC=0b00000000;								// clear D7
//			b=0;
//		}
//	}
//	else													// A0=0, KBD or DSP
//	{
//		U1TXB='3';
//		//TRISC=b;
//		b=0;
//	}
//	U1TXB='r';
	TRISC=0x00;
//	PORTC=0xFF;
	LATC=0b11111111;
//	__delay_ms(10);
	CLCSELECTbits.SLCT=0b11;								// select CLC4
	CLCSELECTbits.SLCT=0b11;								// select CLC4
	CLCSELECTbits.SLCT=0b11;								// select CLC4
	CLCSELECTbits.SLCT=0b11;								// select CLC4
	CLCSELECTbits.SLCT=0b11;								// select CLC4
	CLCSELECTbits.SLCT=0b11;								// select CLC4
	CLCSELECTbits.SLCT=0b11;								// select CLC4
	CLCSELECTbits.SLCT=0b11;								// select CLC4
	CLCSELECTbits.SLCT=0b11;								// select CLC4
	CLCSELECTbits.SLCT=0b11;								// select CLC4
	CLCSELECTbits.SLCT=0b11;								// select CLC4
	CLCSELECTbits.SLCT=0b11;								// select CLC4
	CLCSELECTbits.SLCT=0b11;								// select CLC4
	CLCSELECTbits.SLCT=0b11;								// select CLC4
	CLCSELECTbits.SLCT=0b11;								// select CLC4

	CLCSELECTbits.SLCT=0b11;								// select CLC4
	CLCnPOLbits.POL=1;										// output of logic cell not inverted
//	TRISC=0xFF;

	CLCnPOLbits.POL=0;										// output of logic cell not inverted
	TRISC=0xFF;

	PIR5bits.CLC2IF=0;
}
//
//*************************************************************
//*** CLC3 INTERRUPT ******************************************
//*************************************************************
// 6502 WRITES BYTE TO UART
void __interrupt(irq(CLC3),high_priority,base(8)) CLC3_vect_isr()
{ 
//	U1TXB='W';
	
/*
	uint8_t b=PORTC;
	U1TXB=b & 0b01111111;									// remove bit 7

 */	
	CLCSELECTbits.SLCT=0b11;								// select CLC4	
	CLCnPOLbits.POL=1;										// output of logic cell not inverted
	CLCnPOLbits.POL=0;										// output of logic cell not inverted
	PIR7bits.CLC3IF=0;										// clear CLC3 interrupt flag
}
//
//*************************************************************
//*** CLC4 INTERRUPT ******************************************
//*************************************************************
// NOT USED
void __interrupt(irq(CLC4),high_priority,base(8)) CLC4_vect_isr()
{   
	PIR8bits.CLC4IF=0;										// clear CLC4 interrupt flag
}
//
//*************************************************************
//*** END *****************************************************
//*************************************************************
//