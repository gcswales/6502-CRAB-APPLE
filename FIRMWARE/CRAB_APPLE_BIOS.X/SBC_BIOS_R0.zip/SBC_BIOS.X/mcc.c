//*************************************************************
//***	FILE:		MAIN.C									***
//***	DATE:		26/09/22								***
//***	AUTHOR:		GEOFFREY SWALES							***
//***	VERSION:	V0.1									***
//*************************************************************
//***	DESCRIPTION:										***
//*************************************************************
//***	VERSION TRACK:										***
//***	V0.1: INITIAL DEVELOPMENT VERSION					***
//***	V1.0:												***
//*************************************************************
//	
//*************************************************************
//*** INCLUDE REQUIRED SPECIFIC DEFINTIONS ********************
//*************************************************************
//
#include "mcc.h"
//
//*************************************************************
//*** STRUCTURE DEFINITIONS ***********************************
//*************************************************************
//

//
//*************************************************************
//*** GLOBAL VARIABLES ****************************************
//*************************************************************
//

//
//*************************************************************
//*** INITIALISE CONFIGURATION LOGIC **************************
//*************************************************************
//
void system_init(void)
{
	interrupt_init();
    peripheral_disable_init();
    pin_init();
    oscillator_init();
}
//
//*************************************************************
//*** INITIALISE CONFIGURATION LOGIC **************************
//*************************************************************
//
void oscillator_init(void)
{
	OSCCON1 = 0x60;
	OSCCON3 = 0x00;
	OSCEN = 0x00;
	OSCFRQ = 0x08;
	OSCTUNE = 0x00;
	ACTCON = 0x00;
}
//
//*************************************************************
//*** INITIALISE CONFIGURATION LOGIC **************************
//*************************************************************
//
void peripheral_disable_init(void)
{
    PMD0bits.SYSCMD=0;										// enable: system clock network
	PMD0bits.FVRMD=1;										// disable: fixed voltage reference
	PMD0bits.LVDMD=1;										// disable: low-voltage detect
	PMD0bits.CRCMD=1;										// disable: CRC module
	PMD0bits.SCANMD=0;										// enable: NV Memory scan
	PMD0bits.CLKRMD=0;										// enable: clock reference module
	PMD0bits.IOCMD=1;										// disable interrupt on change
 //
	PMD1bits.CM1MD=1;										// disable: comparator 1
    PMD1bits.ZCDMD=1;										// disable: zero-cross detect
    PMD1bits.SMT1MD=1;										// disable: signal measurement timer
    PMD1bits.TMR0MD=1;										// disable: timer0
    PMD1bits.TMR1MD=1;										// disable: timer1
    PMD1bits.TMR2MD=1;										// disable: timer2
    PMD1bits.TMR3MD=1;										// disable: timer3
    PMD1bits.TMR4MD=1;										// disable: timer4
//
    PMD2bits.CCP1MD=1;										// disable: capture & compare 1
	PMD2bits.CWG1MD=1;										// disable: complimentary wave form generator 1
	PMD2bits.DSM1MD=0;										// enable: digital signal modulator
	PMD2bits.NCO1MD=1;										// disable: numerically controller oscillator
	PMD2bits.ACTMD=1;										// disable: active clock tuning
	PMD2bits.DAC1MD=1;										// disable: digital to analogue converter
	PMD2bits.ADCMD=1;										// disable: analogue to digital converter
	PMD2bits.CM2MD=1;										// disable: comparator 2
//
	PMD3bits.U1MD=0;										// enable: uart 1 module
	PMD3bits.U2MD=1;										// disable: uart 2 module
	PMD3bits.SPI2MD=1;										// disable: spi2
	PMD3bits.SPI1MD=1;										// disable: spi1
	PMD3bits.I2C1MD=1;										// disable: i2c1
	PMD3bits.PWM3MD=1;										// disable: pwm3
	PMD3bits.PWM2MD=1;										// disable: pwm2
	PMD3bits.PWM1MD=1;										// disable:	pwm1
//
    PMD4bits.DMA3MD=1;										// disable: DMA3
    PMD4bits.DMA2MD=1;										// disable: DMA2
    PMD4bits.DMA1MD=1;										// disable: DMA1
    PMD4bits.CLC4MD=0;										// enable: CLC4
    PMD4bits.CLC3MD=0;										// enable: CLC3
    PMD4bits.CLC2MD=0;										// enable: CLC2
    PMD4bits.CLC1MD=0;										// enable: CLC1
    PMD4bits.U3MD=1;										// enable: UART3
//
    PMD5bits.DAC2MD=1;										// disable: DAC2
    PMD5bits.DMA4MD=1;										// disable:	DMA4
}
//
//*************************************************************
//*** INITIALISE CONFIGURATION LOGIC **************************
//*************************************************************
//
void pin_init(void)
{
    //*** CONFIGURE INPUT TYPE (SCHMITT/TTL) ***
	INLVLA = 0x00;
    INLVLB = 0x00;
    INLVLC = 0x00;
    //*** TURN ALL ANALOG INPUTS OFF ***
    ANSELA = 0x00;
    ANSELB = 0x00;
    ANSELC = 0x00;	
    //*** CONFIGURE WEAK PULL-UPS ***
    WPUB = 0x00;
    WPUA = 0x00;
    WPUC = 0x00;	
	//*** SLEW RATE AT MAXIMUM ***
	SLRCONA = 0x00;
	SLRCONB = 0x00;
	SLRCONC = 0x00;
	//
	//*** RESET PIN ***
	TRISAbits.TRISA5=1;			// reset line in an input
//	RA5PPS=0b00000000;			// remap RA5 to LATA5
	//
	//*** A0 PIN ***
	TRISBbits.TRISB7=1;			// A0 line is input
//	RB7PPS=0b00000000;			// remap RB7 to LATB7
	//
	//*** ROM_CS PIN ***
	TRISBbits.TRISB5=1;			// #cs1 line is input
	CLCIN0PPS = 0b00001101;		// CLCIN0=PORTB PIN 5
	//
	//*** IO_CS PIN ***
	TRISBbits.TRISB4=1;			// #cs2 line is input
	CLCIN1PPS = 0b00001100;		// CLCIN1=PORTB PIN 4
	//
	//*** A4 PIN ***
	TRISBbits.TRISB6=1;			// enable line is input
	CLCIN2PPS = 0b00001110;		// CLCIN2=PORTB PIN 6
	//
	//*** W/R PIN ***
	TRISAbits.TRISA2=1;			// r/#w line is input
	CLCIN3PPS = 0b00000010;		// CLCIN3=PORTA PIN 2
	//
	//*** CLOCK PIN ***	
	LATAbits.LATA4=1;										// clock line taken high
	TRISAbits.TRISA4=0;										// clock line is an output
	RA4PPS = 0x26;											// DSM1 output to PIN A4	
	//
	//*** DATA PORT ***
	TRISC = 0xFF;				// data port is input (D0 - D7)
	RC0PPS = 0x00;
	RC1PPS = 0x00;
	RC2PPS = 0x00;
	RC3PPS = 0x00;
	RC4PPS = 0x00;
	RC5PPS = 0x00;
	RC6PPS = 0x00;
	RC7PPS = 0x00;
	LATC=0x00;					// all outputs are low
}
//
//*************************************************************
//*** INITIALISE CONFIGURATION LOGIC **************************
//*************************************************************
//
void interrupt_init(void)
{
    INTCON0bits.IPEN = 1;
    bool state = (unsigned char)GIE;
    GIE = 0;
    IVTLOCK = 0x55;
    IVTLOCK = 0xAA;
    IVTLOCKbits.IVTLOCKED = 0x00; // unlock IVT
    IVTBASEU = 0;
    IVTBASEH = 0;
    IVTBASEL = 8;
    IVTLOCK = 0x55;
    IVTLOCK = 0xAA;
    IVTLOCKbits.IVTLOCKED = 0x01; // lock IVT
    GIE = state;
}
//
//*************************************************************
//*** INITIALISE CONFIGURATION LOGIC **************************
//*************************************************************
//
