//*************************************************************
//***	FILE:		RTOS_PIPE.C								***
//***	DATE:		07/09/21								***
//***	AUTHOR:		GEOFFREY SWALES							***
//***	VERSION:	V0.1									***
//*************************************************************
//***	DESCRIPTION:										***
//***	PIPES ARE SELF-CONTAINED CIRCULAR BUFFERS WHERE  	***
//***	DATA CAN BE EASILY PUT OR GET FROM BY SIMPLY USING	***
//***	A POINTER TO THE PIPE.								***
//***	THE ROUTINES ARE ATOMIC, SO SAFE TO USE IN BOTH		***
//***	MAIN CODE AND INTERRUPTS.							***
//***	THE WRITE & READ FUNCTIONS CAN BE USED TO PASS		***
//***	OBJECTS OF ANY SIZE, SUCH AS FUNCTION POINTERS, ETC	***
//*************************************************************
//***	VERSION TRACK:										***
//***	V0.1: INITIAL DEVELOPMENT VERSION					***
//***	V1.0:												***
//*************************************************************
//	
//*************************************************************
//*** INCLUDE REQUIRED SPECIFIC DEFINTIONS ********************
//*************************************************************
//
#include "PIPE.h"									// include definitions
//
//*************************************************************
//*** STRUCTURE DEFINITIONS ***********************************
//*************************************************************
//

//
//*************************************************************
//*** GLOBAL VARIABLES ****************************************
//*************************************************************
//

//
//*************************************************************
//*** INITIALISE A PIPE ***************************************
//*************************************************************
//
void pipe_init(_pipe_header * h, _pipe_buffer * b, uint16_t s)// initialises/builds pipe from header and buffer
{
	h->buffer=b;											// attach buffer to pipe
	h->in=0;												// clear pipe buffer in index
	h->out=0;												// clear pipe buffer out index
	h->size=s;												// record size of pipe buffer (for wrap-around)
}
//
//*************************************************************
//*** RESET A PIPE ********************************************
//*************************************************************
//
void pipe_reset(_pipe_header * h)
{
//	bool isr_state=EVIC_INT_Disable();						// store state of global interrupt & disable
	h->in=0;												// clear pipe buffer in index
	h->out=0;												// clear pipe buffer out index
//	EVIC_INT_Restore(isr_state);							// restore state of global interrupt
}
//
//*************************************************************
//*** PUT BYTE INTO A PIPE ************************************
//*************************************************************
//
void pipe_put(_pipe_header * h, uint8_t d)					// hand function pipe and byte
{
//	bool isr_state=EVIC_INT_Disable();						// store state of global interrupt & disable
	h->buffer[h->in]=d;										// put byte into buffer at 'in' index
	h->in=(h->in+1)%h->size;								// increment 'in' index with wrap-around
//	EVIC_INT_Restore(isr_state);							// restore state of global interrupt
}
//
//*************************************************************
//*** GET BYTE FROM A PIPE ************************************
//*************************************************************
//
uint8_t pipe_get(_pipe_header * h)							// hand function pipe, to get byte
{
//	bool isr_state=EVIC_INT_Disable();						// store state of global interrupt & disable
	uint8_t t=h->buffer[h->out];							// get byte from buffer at 'out' index
	h->out=(h->out+1)%h->size;								// increment 'out' index with wrap-around
//	EVIC_INT_Restore(isr_state);							// restore state of global interrupt
	return(t);												// return byte read from buffer
}
//
//*************************************************************
//*** RETURNS BYTE COUNT IN A PIPE ****************************
//*************************************************************
//
uint16_t pipe_data(_pipe_header * h)						// returns number of bytes in pipe
{
//	bool isr_state=EVIC_INT_Disable();						// store state of global interrupt & disable
	uint16_t c = h->in;										// start from the in index
	if(h->out > h->in)										// if 'in' index has wrapped-around
	{
		c += h->size;										// add the count on to the in index	
	}
	c -= h->out;											// finally take away the out index
//	EVIC_INT_Restore(isr_state);							// restore state of global interrupt
	return(c);												// return the count
}
//
//*************************************************************
//*** RETURNS BYTE SPACE LEFT IN A PIPE ***********************
//*************************************************************
//
uint16_t pipe_space(_pipe_header * h)						// returns number of bytes in pipe
{
//	bool isr_state=EVIC_INT_Disable();						// store state of global interrupt & disable
	uint16_t t=h->size- pipe_data(h);						// space is buffer size - bytes already in buffer
//	EVIC_INT_Restore(isr_state);							// restore state of global interrupt
	return(t);												// return space left
}
//*************************************************************
//*** READ OBJECT FROM A PIPE *********************************
//*************************************************************
void pipe_read(_pipe_header * h, uint8_t * obj, uint16_t len)// reads any sized object out of the pipe
{
	while(len--)											// while we haven't read the full length...
	{
		*obj++=pipe_get(h);									// read into pointer memory another byte, then inc. pointer
	}
}
//*************************************************************
//*** WRITE OBJECT INTO A PIPE ********************************
//*************************************************************
void pipe_write(_pipe_header * h,uint8_t * obj, uint16_t len)// writes any sized object into a pipe
{
	while(len--)											// while we haven't written the full length...
	{
		pipe_put(h, *obj++);								// put memory content into pipe, then increment pointer		
	}
}
//
//*************************************************************
//*** END *****************************************************
//*************************************************************